import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateGitHubRepoEffects } from './auditComparison';
import { REVIEWS_DATABASE, PRODUCT_DATASETS } from '../data/opinionData';

test('evaluateGitHubRepoEffects computes accurate diagnosis', () => {
  const result = evaluateGitHubRepoEffects();
  assert.equal(result.totalChecks, 7);
  assert.equal(result.criteria.length, 7);
  assert.equal(result.brokenCount > 0, true);
  assert.equal(result.missingCount > 0, true);
  assert.ok(result.overallScore < 50, 'Overall score should reflect that repo failed to apply design properly');
  assert.ok(result.verdict.includes('NOT applied properly'));
});

test('REVIEWS_DATABASE contains expected verified reviews', () => {
  assert.ok(REVIEWS_DATABASE['15'], 'Review #15 must exist');
  assert.equal(REVIEWS_DATABASE['15'].isRisk, true);
  assert.equal(REVIEWS_DATABASE['15'].sentiment, 'Negative');
  assert.ok(REVIEWS_DATABASE['12'], 'Review #12 must exist');
  assert.equal(REVIEWS_DATABASE['12'].isRisk, false);
  assert.equal(REVIEWS_DATABASE['12'].sentiment, 'Positive');
});

test('PRODUCT_DATASETS contains Lenovo with safety warning', () => {
  const lenovo = PRODUCT_DATASETS.find((d) => d.brandId === 'lenovo');
  assert.ok(lenovo, 'Lenovo brand exists');
  const a6000 = lenovo.models.find((m) => m.id === 'MOBE7JXXKS6PWW2C');
  assert.ok(a6000, 'A6000 Plus model exists');
  assert.equal(a6000.hasSafetyWarning, true);
  assert.ok(a6000.safetyWarning);
  assert.equal(a6000.safetyWarning.detectedReviews.includes('15'), true);
  assert.equal(a6000.contestedAspect.title, 'Camera Low-Light Quality');
});
